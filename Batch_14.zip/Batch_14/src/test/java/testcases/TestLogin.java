package testcases;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import io.qameta.allure.Description;
import pages.DarazLoginPage;
import utilities.DataSet;
import utilities.DriverSetup;

public class TestLogin extends DriverSetup {
 
	DarazLoginPage loginpage = new DarazLoginPage();
	
	@Test(description = "Test Login with Invalid credentials 1")
	@Description("Test Login with Invalid credentials from Allure")
	public void testLogInWithInValidCredentials() {
		getDriver().get(loginpage.LOGINPAGE_URL);
		loginpage.doLogin("01111111", "password");
		assertEquals(loginpage.getErrorMassege(), loginpage.ERROR_MASSEGE_TEXT);
}
	@Test
	public void testLogInWithInValidCredentialsPassword() {
		getDriver().get(loginpage.LOGINPAGE_URL);
		loginpage.doLogin("01724444444", "password");
		assertEquals(loginpage.getErrorMassege(), loginpage.ERROR_MASSEGE_PASSWORD_TEXT);
}
	
	
	@Test(dataProvider = "InvalidCredentials", dataProviderClass = DataSet.class)
	public void testLoginWithInvalidCredentialsUsingDataProvider(String username, String password, String massege) {
		getDriver().get(loginpage.LOGINPAGE_URL);	
		loginpage.doLogin(username, password);
		assertEquals(loginpage.getErrorMassege(), massege);
		
	}
}