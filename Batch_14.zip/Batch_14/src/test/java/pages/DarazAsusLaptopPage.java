package pages;

import org.openqa.selenium.By;

public class DarazAsusLaptopPage extends BasePage {
	
	public String ASUS_PAGE_TITLE ="Asus Laptops - Asus Laptop Price in Bangladesh 2023 - Daraz.com.bd";
	
	public By ASUS_LAPTOP_PAGE = By.xpath("//span[normalize-space()='Asus Laptops']");
	public By PRICE_HIGH_TO_LOW = By.xpath("//button[@class='ant-btn filter-price__btn--F4CmC ant-btn-primary ant-btn-icon-only']");
	public By LAPTOP_MODEL_SELECT = By.xpath("//a[contains(text(),'Asus X515JA Core i5 10th Gen Laptop - 8GB DDR4 RAM')]");
	

}
